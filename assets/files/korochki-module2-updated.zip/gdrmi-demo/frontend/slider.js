document.addEventListener("DOMContentLoaded", () => {
  const slider = document.getElementById("slider");
  if (!slider) return;

  const slides = Array.from(slider.querySelectorAll(".slide"));
  const btnPrev = slider.querySelector(".slider-btn.prev");
  const btnNext = slider.querySelector(".slider-btn.next");

  if (slides.length === 0) return;

  let index = 0;
  let timerId = null;
  const intervalMs = 3000;

  function showSlide(newIndex) {
    slides[index].classList.remove("is-active");
    index = (newIndex + slides.length) % slides.length;
    slides[index].classList.add("is-active");
  }

  function next() { showSlide(index + 1); }
  function prev() { showSlide(index - 1); }

  function startAuto() {
    stopAuto();
    timerId = window.setInterval(next, intervalMs);
  }

  function stopAuto() {
    if (timerId) {
      window.clearInterval(timerId);
      timerId = null;
    }
  }

  btnNext?.addEventListener("click", () => { next(); startAuto(); });
  btnPrev?.addEventListener("click", () => { prev(); startAuto(); });

  // микроанимация UX: пауза при наведении
  slider.addEventListener("mouseenter", stopAuto);
  slider.addEventListener("mouseleave", startAuto);

  // на мобильном: пауза при касании
  slider.addEventListener("touchstart", stopAuto, { passive: true });
  slider.addEventListener("touchend", startAuto);

  startAuto();
});
