USE korochki;

-- 1) создать справочник курсов
CREATE TABLE IF NOT EXISTS courses (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(200) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2) заполнить 3 курса из задания
INSERT IGNORE INTO courses (name) VALUES
('Основы алгоритмизации и программирования'),
('Основы веб-дизайна'),
('Основы проектирования баз данных');

-- 3) добавить course_id в applications
ALTER TABLE applications
  ADD COLUMN course_id INT NULL AFTER user_id;

-- 4) проставить course_id по старому course_name
UPDATE applications a
JOIN courses c ON c.name = a.course_name
SET a.course_id = c.id;

-- 5) сделать course_id обязательным и добавить FK
ALTER TABLE applications
  MODIFY course_id INT NOT NULL,
  ADD CONSTRAINT fk_applications_course
    FOREIGN KEY (course_id) REFERENCES courses(id)
    ON UPDATE CASCADE;

-- 6) убрать старое поле (после успешного обновления)
ALTER TABLE applications
  DROP COLUMN course_name;
