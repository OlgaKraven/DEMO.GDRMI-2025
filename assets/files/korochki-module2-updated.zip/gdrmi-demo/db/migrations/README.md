# Миграции БД (модуль 2)

## Как применять

1. Открыть phpMyAdmin → база `korochki` → вкладка **SQL**.
2. Выполнить миграции по порядку:

- `001_fix_schema.sql`
- `002_courses_dictionary.sql`

## Что меняется

- `users.login` → NOT NULL
- `users.email` → UNIQUE
- `reviews.created_at` → TIMESTAMP DEFAULT CURRENT_TIMESTAMP
- Добавляется таблица `courses` и в `applications` появляется `course_id` вместо `course_name`

## Совместимость

Backend умеет работать и **до**, и **после** миграции 002 (он проверяет наличие `applications.course_id`).
