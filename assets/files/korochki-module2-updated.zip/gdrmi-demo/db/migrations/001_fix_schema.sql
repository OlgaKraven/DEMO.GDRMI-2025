USE korochki;

-- 1) login сделать обязательным
ALTER TABLE users
  MODIFY login VARCHAR(50) NOT NULL;

-- 2) email сделать уникальным
ALTER TABLE users
  ADD UNIQUE KEY uq_users_email (email);

-- 3) reviews.created_at сделать timestamp с автозаполнением
ALTER TABLE reviews
  MODIFY created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;

-- 4) reviews.text расширить
ALTER TABLE reviews
  MODIFY text TEXT NOT NULL;

-- 5) payment_methods.name сделать уникальным (справочник)
ALTER TABLE payment_methods
  ADD UNIQUE KEY uq_payment_methods_name (name);
