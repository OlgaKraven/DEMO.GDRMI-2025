from flask import Flask, request, jsonify, send_from_directory
import os
import re
import hashlib
import pymysql
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# ====== Настройки MySQL (XAMPP) ======
DB_CONFIG = {
    "host": "127.0.0.1",
    "user": "root",
    "password": "",       # в XAMPP часто пустой пароль
    "database": "korochki",
    "charset": "utf8mb4",
    "cursorclass": pymysql.cursors.DictCursor
}

# ====== Регулярные выражения под задание ======
RE_LOGIN = re.compile(r"^[A-Za-z]{4,}$")
RE_FULL_NAME = re.compile(r"^[А-Яа-яЁё\s]+$")
RE_PHONE = re.compile(r"^8\(\d{3}\)\d{3}-\d{2}-\d{2}$")
RE_EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def hash_password(password: str) -> str:
    # Для учебной задачи достаточно sha256
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


def db_conn():
    return pymysql.connect(**DB_CONFIG)


BASE_DIR = os.path.dirname(__file__)
FRONTEND_DIR = os.path.join(BASE_DIR, "..", "frontend")


def has_column(table_name: str, column_name: str) -> bool:
    """Проверить наличие колонки в БД (чтобы проект работал и до/после миграции 002)."""
    try:
        conn = db_conn()
        with conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT 1
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND COLUMN_NAME = %s
                    LIMIT 1
                    """,
                    (DB_CONFIG["database"], table_name, column_name)
                )
                return cur.fetchone() is not None
    except Exception:
        return False


USE_COURSES = has_column("applications", "course_id")


# =========================
# Frontend routes
# =========================
@app.get("/")
def root():
    return send_from_directory(FRONTEND_DIR, "login.html")


@app.get("/login")
def login_page():
    return send_from_directory(FRONTEND_DIR, "login.html")


@app.get("/register")
def register_page():
    return send_from_directory(FRONTEND_DIR, "register.html")


@app.get("/applications")
def applications_page():
    return send_from_directory(FRONTEND_DIR, "applications.html")


@app.get("/create_application")
def create_application_page():
    return send_from_directory(FRONTEND_DIR, "create_application.html")


@app.get("/admin")
def admin_page():
    return send_from_directory(FRONTEND_DIR, "admin.html")


@app.get("/styles.css")
def styles_css():
    return send_from_directory(FRONTEND_DIR, "styles.css")


@app.get("/slider.js")
def slider_js():
    return send_from_directory(FRONTEND_DIR, "slider.js")


@app.get("/assets/<path:filepath>")
def assets(filepath):
    return send_from_directory(os.path.join(FRONTEND_DIR, "assets"), filepath)


# =========================
# API
# =========================
@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "use_courses": USE_COURSES}), 200


@app.get("/api/courses")
def list_courses():
    """Удобно для фронтенда (если захотите генерировать список курсов из БД)."""
    if not USE_COURSES:
        return jsonify({
            "courses": [
                "Основы алгоритмизации и программирования",
                "Основы веб-дизайна",
                "Основы проектирования баз данных",
            ],
            "source": "static"
        }), 200

    try:
        conn = db_conn()
        with conn:
            with conn.cursor() as cur:
                cur.execute("SELECT id, name FROM courses ORDER BY id ASC")
                rows = cur.fetchall()
        return jsonify({"courses": rows, "source": "db"}), 200
    except Exception:
        return jsonify({"error": "Ошибка сервера или базы данных."}), 500


@app.post("/api/register")
def register():
    data = request.get_json(silent=True) or {}

    login = (data.get("login") or "").strip()
    password = data.get("password") or ""
    full_name = (data.get("full_name") or "").strip()
    phone = (data.get("phone") or "").strip()
    email = (data.get("email") or "").strip()

    if not all([login, password, full_name, phone, email]):
        return jsonify({"error": "Все поля обязательны для заполнения."}), 400

    if not RE_LOGIN.match(login):
        return jsonify({"error": "Логин: латиница, не менее 4 символов."}), 400

    if len(password) < 8:
        return jsonify({"error": "Пароль: не менее 8 символов."}), 400

    if not RE_FULL_NAME.match(full_name):
        return jsonify({"error": "ФИО: только кириллица и пробелы."}), 400

    if not RE_PHONE.match(phone):
        return jsonify({"error": "Телефон: формат 8(XXX)XXX-XX-XX."}), 400

    if not RE_EMAIL.match(email):
        return jsonify({"error": "Email: неверный формат."}), 400

    password_hash = hash_password(password)

    try:
        conn = db_conn()
        with conn:
            with conn.cursor() as cur:
                cur.execute("SELECT id FROM users WHERE login=%s OR email=%s", (login, email))
                if cur.fetchone():
                    return jsonify({"error": "Пользователь с таким логином или email уже существует."}), 409

                cur.execute("SELECT id FROM roles WHERE name='user'")
                role = cur.fetchone()
                if not role:
                    return jsonify({"error": "В БД отсутствует роль 'user'."}), 500

                cur.execute(
                    """
                    INSERT INTO users (login, password_hash, full_name, phone, email, role_id)
                    VALUES (%s, %s, %s, %s, %s, %s)
                    """,
                    (login, password_hash, full_name, phone, email, role["id"])
                )
            conn.commit()

        return jsonify({"message": "Пользователь создан."}), 201
    except Exception:
        return jsonify({"error": "Ошибка сервера или базы данных."}), 500


@app.post("/api/login")
def login():
    data = request.get_json(silent=True) or {}

    login_value = (data.get("login") or "").strip()
    password = data.get("password") or ""

    if not login_value or not password:
        return jsonify({"error": "Введите логин и пароль."}), 400

    if not RE_LOGIN.match(login_value):
        return jsonify({"error": "Неверный формат логина."}), 400

    password_hash = hash_password(password)

    try:
        conn = db_conn()
        with conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT u.id, r.name AS role, u.password_hash
                    FROM users u
                    JOIN roles r ON r.id = u.role_id
                    WHERE u.login = %s
                    """,
                    (login_value,)
                )
                user = cur.fetchone()

                if not user or user["password_hash"] != password_hash:
                    return jsonify({"error": "Неверный логин или пароль."}), 401

        return jsonify({"message": "Вход выполнен.", "user_id": user["id"], "role": user["role"]}), 200
    except Exception:
        return jsonify({"error": "Ошибка сервера или базы данных."}), 500


@app.get("/api/applications/my")
def my_applications():
    user_id = request.args.get("user_id", "").strip()
    if not user_id.isdigit():
        return jsonify({"error": "Требуется корректный user_id."}), 400

    try:
        conn = db_conn()
        with conn:
            with conn.cursor() as cur:
                if USE_COURSES:
                    cur.execute(
                        """
                        SELECT
                          a.id,
                          c.name AS course_name,
                          DATE_FORMAT(a.start_date, '%%Y-%%m-%%d') AS start_date,
                          pm.name AS payment_method,
                          st.name AS status,
                          DATE_FORMAT(a.created_at, '%%Y-%%m-%%d %%H:%%i:%%s') AS created_at
                        FROM applications a
                        JOIN courses c ON c.id = a.course_id
                        JOIN payment_methods pm ON pm.id = a.payment_method_id
                        JOIN application_statuses st ON st.id = a.status_id
                        WHERE a.user_id = %s
                        ORDER BY a.id DESC
                        """,
                        (int(user_id),)
                    )
                else:
                    cur.execute(
                        """
                        SELECT
                          a.id,
                          a.course_name,
                          DATE_FORMAT(a.start_date, '%%Y-%%m-%%d') AS start_date,
                          pm.name AS payment_method,
                          st.name AS status,
                          DATE_FORMAT(a.created_at, '%%Y-%%m-%%d %%H:%%i:%%s') AS created_at
                        FROM applications a
                        JOIN payment_methods pm ON pm.id = a.payment_method_id
                        JOIN application_statuses st ON st.id = a.status_id
                        WHERE a.user_id = %s
                        ORDER BY a.id DESC
                        """,
                        (int(user_id),)
                    )
                apps = cur.fetchall()

        return jsonify({"applications": apps}), 200
    except Exception:
        return jsonify({"error": "Ошибка сервера или базы данных."}), 500


def user_has_completed_course(cur, user_id: int) -> bool:
    cur.execute(
        """
        SELECT 1
        FROM applications a
        JOIN application_statuses st ON st.id = a.status_id
        WHERE a.user_id = %s AND st.name = 'Обучение завершено'
        LIMIT 1
        """,
        (user_id,)
    )
    return cur.fetchone() is not None


@app.post("/api/reviews")
def add_review():
    data = request.get_json(silent=True) or {}
    user_id = data.get("user_id")
    text = (data.get("text") or "").strip()

    if not isinstance(user_id, int) or user_id <= 0:
        return jsonify({"error": "Требуется корректный user_id."}), 400

    if not text:
        return jsonify({"error": "Текст отзыва обязателен."}), 400

    try:
        conn = db_conn()
        with conn:
            with conn.cursor() as cur:
                cur.execute("SELECT id FROM users WHERE id=%s", (user_id,))
                if not cur.fetchone():
                    return jsonify({"error": "Пользователь не найден."}), 404

                # Правило задания: отзыв только после завершения курса
                if not user_has_completed_course(cur, user_id):
                    return jsonify({"error": "Оставить отзыв можно только после прохождения курса."}), 403

                cur.execute("INSERT INTO reviews (user_id, text) VALUES (%s, %s)", (user_id, text))
            conn.commit()

        return jsonify({"message": "Отзыв добавлен."}), 201
    except Exception:
        return jsonify({"error": "Ошибка сервера или базы данных."}), 500


@app.post("/api/applications")
def create_application():
    data = request.get_json(silent=True) or {}

    user_id = data.get("user_id")
    course_name = (data.get("course_name") or "").strip()
    start_date = (data.get("start_date") or "").strip()  # ожидается YYYY-MM-DD
    payment_method_name = (data.get("payment_method") or "").strip()

    if not isinstance(user_id, int) or user_id <= 0:
        return jsonify({"error": "Требуется корректный user_id."}), 400

    if not course_name:
        return jsonify({"error": "Наименование курса обязательно."}), 400

    if not start_date:
        return jsonify({"error": "Дата начала обязательна."}), 400

    if payment_method_name not in ("Наличными", "Переводом по номеру телефона"):
        return jsonify({"error": "Выберите способ оплаты."}), 400

    try:
        conn = db_conn()
        with conn:
            with conn.cursor() as cur:
                cur.execute("SELECT id FROM users WHERE id=%s", (user_id,))
                if not cur.fetchone():
                    return jsonify({"error": "Пользователь не найден."}), 404

                cur.execute("SELECT id FROM payment_methods WHERE name=%s", (payment_method_name,))
                pm = cur.fetchone()
                if not pm:
                    return jsonify({"error": "Способ оплаты не найден в справочнике."}), 500

                cur.execute("SELECT id FROM application_statuses WHERE name='Новая'")
                st = cur.fetchone()
                if not st:
                    return jsonify({"error": "Статус 'Новая' не найден в справочнике."}), 500

                if USE_COURSES:
                    cur.execute("SELECT id FROM courses WHERE name=%s", (course_name,))
                    course = cur.fetchone()
                    if not course:
                        return jsonify({"error": "Курс не найден в справочнике."}), 400

                    cur.execute(
                        """
                        INSERT INTO applications (user_id, course_id, start_date, payment_method_id, status_id)
                        VALUES (%s, %s, %s, %s, %s)
                        """,
                        (user_id, course["id"], start_date, pm["id"], st["id"])
                    )
                else:
                    cur.execute(
                        """
                        INSERT INTO applications (user_id, course_name, start_date, payment_method_id, status_id)
                        VALUES (%s, %s, %s, %s, %s)
                        """,
                        (user_id, course_name, start_date, pm["id"], st["id"])
                    )
            conn.commit()

        return jsonify({"message": "Заявка создана."}), 201
    except Exception:
        return jsonify({"error": "Ошибка сервера или базы данных."}), 500


@app.get("/api/admin/applications")
def admin_applications():
    try:
        conn = db_conn()
        with conn:
            with conn.cursor() as cur:
                if USE_COURSES:
                    cur.execute(
                        """
                        SELECT
                          a.id,
                          u.login AS user_login,
                          c.name AS course_name,
                          DATE_FORMAT(a.start_date, '%%Y-%%m-%%d') AS start_date,
                          pm.name AS payment_method,
                          st.name AS status
                        FROM applications a
                        JOIN users u ON u.id = a.user_id
                        JOIN courses c ON c.id = a.course_id
                        JOIN payment_methods pm ON pm.id = a.payment_method_id
                        JOIN application_statuses st ON st.id = a.status_id
                        ORDER BY a.id DESC
                        """
                    )
                else:
                    cur.execute(
                        """
                        SELECT
                          a.id,
                          u.login AS user_login,
                          a.course_name,
                          DATE_FORMAT(a.start_date, '%%Y-%%m-%%d') AS start_date,
                          pm.name AS payment_method,
                          st.name AS status
                        FROM applications a
                        JOIN users u ON u.id = a.user_id
                        JOIN payment_methods pm ON pm.id = a.payment_method_id
                        JOIN application_statuses st ON st.id = a.status_id
                        ORDER BY a.id DESC
                        """
                    )
                apps = cur.fetchall()

        return jsonify({"applications": apps}), 200
    except Exception:
        return jsonify({"error": "Ошибка сервера или базы данных."}), 500


@app.patch("/api/admin/applications/<int:app_id>/status")
def admin_update_status(app_id: int):
    data = request.get_json(silent=True) or {}
    status_name = (data.get("status") or "").strip()

    allowed = {"Идёт обучение", "Обучение завершено", "Новая"}
    if status_name not in allowed:
        return jsonify({"error": "Недопустимый статус."}), 400

    try:
        conn = db_conn()
        with conn:
            with conn.cursor() as cur:
                cur.execute("SELECT id FROM application_statuses WHERE name=%s", (status_name,))
                st = cur.fetchone()
                if not st:
                    return jsonify({"error": "Статус не найден в справочнике."}), 500

                cur.execute("UPDATE applications SET status_id=%s WHERE id=%s", (st["id"], app_id))
                if cur.rowcount == 0:
                    return jsonify({"error": "Заявка не найдена."}), 404

            conn.commit()

        return jsonify({"message": "Статус обновлён."}), 200
    except Exception:
        return jsonify({"error": "Ошибка сервера или базы данных."}), 500


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
