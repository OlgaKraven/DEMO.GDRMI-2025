from flask import Flask, request, jsonify, send_from_directory
import os
from flask_cors import CORS
import re
import pymysql
import hashlib

app = Flask(__name__)
CORS(app)

# ====== Настройки MySQL (XAMPP) ======
DB_CONFIG = {
    "host": "127.0.0.1",
    "user": "root",
    "password": "",       # в XAMPP часто пустой пароль
    "database": "korochki",
    "charset": "utf8mb4",
    "cursorclass": pymysql.cursors.DictCursor
}

# ====== Регулярные выражения под задание ======
RE_LOGIN = re.compile(r"^[A-Za-z]{4,}$")
RE_FULL_NAME = re.compile(r"^[А-Яа-яЁё\s]+$")
RE_PHONE = re.compile(r"^8\(\d{3}\)\d{3}-\d{2}-\d{2}$")
RE_EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

def hash_password(password: str) -> str:
    # Минимально: sha256 (для учебной задачи достаточно)
    return hashlib.sha256(password.encode("utf-8")).hexdigest()

def db_conn():
    return pymysql.connect(**DB_CONFIG)

BASE_DIR = os.path.dirname(__file__)
FRONTEND_DIR = os.path.join(BASE_DIR, "..", "frontend")

@app.get("/")
def root():
    # по умолчанию открываем авторизацию
    return send_from_directory(FRONTEND_DIR, "login.html")

@app.get("/login")
def login_page():
    return send_from_directory(FRONTEND_DIR, "login.html")

@app.get("/register")
def register_page():
    return send_from_directory(FRONTEND_DIR, "register.html")

@app.get("/applications")
def applications_page():
    return send_from_directory(FRONTEND_DIR, "applications.html")

@app.get("/create_application")
def create_application_page():
    return send_from_directory(FRONTEND_DIR, "create_application.html")

@app.get("/admin")
def admin_page():
    return send_from_directory(FRONTEND_DIR, "admin.html")

@app.get("/styles.css")
def styles_css():
    return send_from_directory(FRONTEND_DIR, "styles.css")



@app.post("/api/register")
def register():
    data = request.get_json(silent=True) or {}

    login = (data.get("login") or "").strip()
    password = data.get("password") or ""
    full_name = (data.get("full_name") or "").strip()
    phone = (data.get("phone") or "").strip()
    email = (data.get("email") or "").strip()

    # --- Обязательность полей ---
    if not all([login, password, full_name, phone, email]):
        return jsonify({"error": "Все поля обязательны для заполнения."}), 400

    # --- Валидация по заданию ---
    if not RE_LOGIN.match(login):
        return jsonify({"error": "Логин: латиница, не менее 4 символов."}), 400

    if len(password) < 8:
        return jsonify({"error": "Пароль: не менее 8 символов."}), 400

    if not RE_FULL_NAME.match(full_name):
        return jsonify({"error": "ФИО: только кириллица и пробелы."}), 400

    if not RE_PHONE.match(phone):
        return jsonify({"error": "Телефон: формат 8(XXX)XXX-XX-XX."}), 400

    if not RE_EMAIL.match(email):
        return jsonify({"error": "Email: неверный формат."}), 400

    password_hash = hash_password(password)

    # --- Запись в БД ---
    try:
        conn = db_conn()
        with conn:
            with conn.cursor() as cur:
                # проверка уникальности логина/email
                cur.execute("SELECT id FROM users WHERE login=%s OR email=%s", (login, email))
                exists = cur.fetchone()
                if exists:
                    return jsonify({"error": "Пользователь с таким логином или email уже существует."}), 409

                # role_id = роль 'user'
                cur.execute("SELECT id FROM roles WHERE name='user'")
                role = cur.fetchone()
                if not role:
                    return jsonify({"error": "В БД отсутствует роль 'user'."}), 500

                cur.execute(
                    """
                    INSERT INTO users (login, password_hash, full_name, phone, email, role_id)
                    VALUES (%s, %s, %s, %s, %s, %s)
                    """,
                    (login, password_hash, full_name, phone, email, role["id"])
                )
            conn.commit()

        return jsonify({"message": "Пользователь создан."}), 201

    except Exception:
        return jsonify({"error": "Ошибка сервера или базы данных."}), 500


@app.post("/api/login")
def login():
    data = request.get_json(silent=True) or {}

    login_value = (data.get("login") or "").strip()
    password = data.get("password") or ""

    if not login_value or not password:
        return jsonify({"error": "Введите логин и пароль."}), 400

    # (необязательно, но совпадает с требованиями формата логина)
    if not RE_LOGIN.match(login_value):
        return jsonify({"error": "Неверный формат логина."}), 400

    password_hash = hash_password(password)

    try:
        conn = db_conn()
        with conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT u.id, r.name AS role, u.password_hash
                    FROM users u
                    JOIN roles r ON r.id = u.role_id
                    WHERE u.login = %s
                    """,
                    (login_value,)
                )
                user = cur.fetchone()

                if not user:
                    return jsonify({"error": "Неверный логин или пароль."}), 401

                if user["password_hash"] != password_hash:
                    return jsonify({"error": "Неверный логин или пароль."}), 401

        return jsonify({
            "message": "Вход выполнен.",
            "user_id": user["id"],
            "role": user["role"]
        }), 200

    except Exception:
        return jsonify({"error": "Ошибка сервера или базы данных."}), 500

@app.get("/api/applications/my")
def my_applications():
    user_id = request.args.get("user_id", "").strip()

    if not user_id.isdigit():
        return jsonify({"error": "Требуется корректный user_id."}), 400

    try:
        conn = db_conn()
        with conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT
                      a.id,
                      a.course_name,
                      DATE_FORMAT(a.start_date, '%%Y-%%m-%%d') AS start_date,
                      pm.name AS payment_method,
                      st.name AS status,
                      DATE_FORMAT(a.created_at, '%%Y-%%m-%%d %%H:%%i:%%s') AS created_at
                    FROM applications a
                    JOIN payment_methods pm ON pm.id = a.payment_method_id
                    JOIN application_statuses st ON st.id = a.status_id
                    WHERE a.user_id = %s
                    ORDER BY a.id DESC
                    """,
                    (int(user_id),)
                )
                apps = cur.fetchall()

        return jsonify({"applications": apps}), 200
    except Exception:
        return jsonify({"error": "Ошибка сервера или базы данных."}), 500

@app.post("/api/reviews")
def add_review():
    data = request.get_json(silent=True) or {}

    user_id = data.get("user_id")
    text = (data.get("text") or "").strip()

    if not isinstance(user_id, int) or user_id <= 0:
        return jsonify({"error": "Требуется корректный user_id."}), 400

    if not text:
        return jsonify({"error": "Текст отзыва обязателен."}), 400

    try:
        conn = db_conn()
        with conn:
            with conn.cursor() as cur:
                # проверим, что пользователь существует
                cur.execute("SELECT id FROM users WHERE id=%s", (user_id,))
                if not cur.fetchone():
                    return jsonify({"error": "Пользователь не найден."}), 404

                cur.execute(
                    "INSERT INTO reviews (user_id, text) VALUES (%s, %s)",
                    (user_id, text)
                )
            conn.commit()

        return jsonify({"message": "Отзыв добавлен."}), 201
    except Exception:
        return jsonify({"error": "Ошибка сервера или базы данных."}), 500

@app.post("/api/applications")
def create_application():
    data = request.get_json(silent=True) or {}

    user_id = data.get("user_id")
    course_name = (data.get("course_name") or "").strip()
    start_date = (data.get("start_date") or "").strip()  # формат YYYY-MM-DD
    payment_method_name = (data.get("payment_method") or "").strip()

    if not isinstance(user_id, int) or user_id <= 0:
        return jsonify({"error": "Требуется корректный user_id."}), 400

    if not course_name:
        return jsonify({"error": "Наименование курса обязательно."}), 400

    if not start_date:
        return jsonify({"error": "Дата начала обязательна."}), 400

    if payment_method_name not in ("Наличными", "Переводом по номеру телефона"):
        return jsonify({"error": "Выберите способ оплаты."}), 400

    try:
        conn = db_conn()
        with conn:
            with conn.cursor() as cur:
                # пользователь существует?
                cur.execute("SELECT id FROM users WHERE id=%s", (user_id,))
                if not cur.fetchone():
                    return jsonify({"error": "Пользователь не найден."}), 404

                # payment_method_id по названию
                cur.execute("SELECT id FROM payment_methods WHERE name=%s", (payment_method_name,))
                pm = cur.fetchone()
                if not pm:
                    return jsonify({"error": "Способ оплаты не найден в справочнике."}), 500

                # status_id для "Новая"
                cur.execute("SELECT id FROM application_statuses WHERE name='Новая'")
                st = cur.fetchone()
                if not st:
                    return jsonify({"error": "Статус 'Новая' не найден в справочнике."}), 500

                cur.execute(
                    """
                    INSERT INTO applications (user_id, course_name, start_date, payment_method_id, status_id)
                    VALUES (%s, %s, %s, %s, %s)
                    """,
                    (user_id, course_name, start_date, pm["id"], st["id"])
                )
            conn.commit()

        return jsonify({"message": "Заявка создана."}), 201

    except Exception:
        return jsonify({"error": "Ошибка сервера или базы данных."}), 500

@app.get("/api/admin/applications")
def admin_applications():
    try:
        conn = db_conn()
        with conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT
                      a.id,
                      u.login AS user_login,
                      a.course_name,
                      DATE_FORMAT(a.start_date, '%%Y-%%m-%%d') AS start_date,
                      pm.name AS payment_method,
                      st.name AS status
                    FROM applications a
                    JOIN users u ON u.id = a.user_id
                    JOIN payment_methods pm ON pm.id = a.payment_method_id
                    JOIN application_statuses st ON st.id = a.status_id
                    ORDER BY a.id DESC
                    """
                )
                apps = cur.fetchall()

        return jsonify({"applications": apps}), 200
    except Exception:
        return jsonify({"error": "Ошибка сервера или базы данных."}), 500
    
@app.patch("/api/admin/applications/<int:app_id>/status")
def admin_update_status(app_id: int):
    data = request.get_json(silent=True) or {}
    status_name = (data.get("status") or "").strip()

    # По заданию админ может установить только эти статусы
    allowed = {"Идёт обучение", "Обучение завершено", "Новая"}
    if status_name not in allowed:
        return jsonify({"error": "Недопустимый статус."}), 400

    try:
        conn = db_conn()
        with conn:
            with conn.cursor() as cur:
                # получить id статуса по названию
                cur.execute("SELECT id FROM application_statuses WHERE name=%s", (status_name,))
                st = cur.fetchone()
                if not st:
                    return jsonify({"error": "Статус не найден в справочнике."}), 500

                # обновить статус заявки
                cur.execute("UPDATE applications SET status_id=%s WHERE id=%s", (st["id"], app_id))
                if cur.rowcount == 0:
                    return jsonify({"error": "Заявка не найдена."}), 404

            conn.commit()

        return jsonify({"message": "Статус обновлён."}), 200
    except Exception:
        return jsonify({"error": "Ошибка сервера или базы данных."}), 500

@app.get("/styles.css")
def styles():
    frontend_dir = os.path.join(os.path.dirname(__file__), "..", "frontend")
    return send_from_directory(frontend_dir, "styles.css")


import hashlib
print(hashlib.sha256("KorokNET".encode("utf-8")).hexdigest())

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)